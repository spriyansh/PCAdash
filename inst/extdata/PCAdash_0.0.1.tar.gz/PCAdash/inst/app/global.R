## Load PCAdash globally
suppressPackageStartupMessages({
  library(PCAdash)
})

## Make Data available globally
data("pTime", package = "PCAdash")
data("metagene_results", package = "PCAdash")
data("cell_type", package = "PCAdash")
data("tsne_coords", package = "PCAdash")
data("counts", package = "PCAdash")

#
# options(shiny.autoreload = TRUE)
# shiny::runApp(
#     appDir = "/home/priyansh/gitDockers/PCAdash/inst/app/",
#     launch.browser = TRUE, display.mode = "normal"
# )
#
